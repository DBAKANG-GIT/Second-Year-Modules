#include <iostream>
#include <iomanip>
#include <string>
#include "FinanceProgram.h"
#include "CandleStickManger.h"
#include "Candle.h"

using namespace std;

int main()
{
	FinanceProgram(cout);

	return 0;
}